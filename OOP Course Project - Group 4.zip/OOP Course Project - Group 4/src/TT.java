import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
class TT{
    TT(){
        JFrame f=new JFrame("Group 4 - Project");
        JLabel heading=new JLabel("Railway Ticket Reservation System");
        JLabel USR=new JLabel("Username");
        JTextField USR_ENT=new JTextField("");
        JLabel PASS=new JLabel("Password");
        JPasswordField PASS_ENT=new JPasswordField("");
        JButton LOG=new JButton("Login");
        heading.setBounds(200,105,500,30);
        heading.setFont(new Font("Arial",Font.PLAIN,30));
        heading.setForeground(Color.blue);
        f.getContentPane().setBackground(Color.cyan);
        f.add(heading);
        USR.setBounds(250,200,95,30);
        USR.setForeground(Color.darkGray);
        f.add(USR);
        USR_ENT.setBounds(440,200,130,30);
        f.add(USR_ENT);
        PASS.setBounds(250,250,95,30);
        PASS.setForeground(Color.darkGray);
        f.add(PASS);
        PASS_ENT.setBounds(440,250,130,30);
        f.add(PASS_ENT);
        LOG.setBounds(395,305,95,30);
        f.add(LOG);
        LOG.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                String uname=USR_ENT.getText();
                String psd=PASS_ENT.getText();
                if(uname.equals("USER")&&psd.equals("1234"))
                {
                    LOG.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent ae){
                            f.dispose();
                            new Railways();
                        }});
                }
                else{JOptionPane.showMessageDialog(f,"Hint: USER,1234");
                }
            }
        });
        f.setSize(900,600);
        f.setLayout(null);
        f.setVisible(true);
        f.setResizable(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String[]args)
    {new TT();
    }
}
class Railways{
    int amount=0;
    JFrame f=new JFrame("Railways Reservation ");
    public Railways()
    {
        f.getContentPane().setBackground(Color.ORANGE);
        JLabel BOOK=new JLabel("BOOKING");
        JLabel DPCT=new JLabel(" Departure City:");
        JLabel ARCT=new JLabel(" Destination City:");
        JLabel GENDER=new JLabel(" Gender: ");
        JRadioButton MALE=new JRadioButton("Male");
        JRadioButton FEMALE=new JRadioButton("Female");
        JRadioButton OTHER=new JRadioButton("Other");
        JLabel TRAIN=new JLabel("Trains: ");
        String TR[]={"SELECT","Gatimaan Express","Chennai Express", "Shatabdi Express","Rajadhani Express","Maharaja Express"};
        String DEP[]={"SELECT","DELHI","CHENNAI","HYDERABAD","KOLKATA","MUMBAI","BANGALORE", "VIJAYAWADA"};
        String ARR[]={"SELECT","DELHI","CHENNAI","HYDERABAD","KOLKATA","MUMBAI","BANGALORE", "VIJAYAWADA"};

        JLabel TIMING=new JLabel("Time :");
        String TIME[]={"SELECT","9:00 AM","10:00 AM","11:00 AM","5:30 PM","9:30 PM","11:00 PM","1:00 AM","2:00 AM","2:30 AM"};
        JComboBox TIM=new JComboBox(TIME);
        JLabel CL=new JLabel("Class:");
        JRadioButton T1=new JRadioButton("1- TIER");
        JRadioButton T2=new JRadioButton("2 - TIER");
        JRadioButton GEN=new JRadioButton("GENERAL");
        ButtonGroup G=new ButtonGroup();
        G.add(T1);
        G.add(T2);
        G.add(GEN);
        JLabel SEAT=new JLabel("Seats: ");
        Choice ch=new Choice();
        ch.add("0");
        ch.add("1");
        ch.add("2");
        ch.add("3");

        JLabel TYPE=new JLabel("Type:");
        JRadioButton AC=new JRadioButton("AC");
        JRadioButton NON=new JRadioButton("NON-AC");
        ButtonGroup p=new ButtonGroup();
        p.add(AC);
        p.add(NON);
        JButton SUB=new JButton("Submit");
        SUB.setBounds(191,630,95,20);
        f.add(SUB);
        BOOK.setFont(new Font("Times New Roman",Font.PLAIN,30));
        BOOK.setBounds(150,70,250,30);
        f.add(BOOK);
        DPCT.setBounds(50,150,105,30);
        f.add(DPCT);
        JComboBox DP=new JComboBox(DEP);
        DP.setBounds(175,157,100,20);
        f.add(DP);
        ARCT.setBounds(50,170,150,95);
        f.add(ARCT);
        JComboBox AR=new JComboBox(ARR);
        AR.setBounds(175,207,100,20);
        f.add(AR);
        GENDER.setBounds(50,250,95,30);
        f.add(GENDER);
        MALE.setBounds(150,250,95,30);
        f.add(MALE);
        FEMALE.setBounds(250,250,95,30);
        f.add(FEMALE);
        OTHER.setBounds(350,250,95,30);
        f.add(OTHER);
        ButtonGroup H=new ButtonGroup();
        H.add(MALE);
        H.add(FEMALE);
        H.add(OTHER);
        TRAIN.setBounds(50,300,135,30);
        f.add(TRAIN);
        JComboBox trains=new JComboBox(TR);
        trains.setBounds(175,310,200,20);
        f.add(trains);
        TIMING.setBounds(50,370,135,30);
        f.add(TIMING);
        TIM.setBounds(175,375,100,20);
        f.add(TIM);
        CL.setBounds(50,410,150,30);
        f.add(CL);
        T1.setBounds(150,410,95,30);
        f.add(T1);
        T2.setBounds(250,410,95,30);
        f.add(T2);
        GEN.setBounds(350,410,95,30);
        f.add(GEN);
        SEAT.setBounds(50,450,145,30);
        f.add(SEAT);
        ch.setBounds(200,460,100,20);
        f.add(ch);

        TYPE.setBounds(50,560,135,30);
        f.add(TYPE);
        AC.setBounds(160,560,140,35);
        f.add(AC);
        NON.setBounds(320,560,140,35);
        f.add(NON);
        SUB.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                String d= ch.getItem(ch.getSelectedIndex());

                if(d=="0"){
                    amount=0;
                }
                if(d=="1"){
                    amount=700;
                }
                if(d=="2"){
                    amount=1400;
                }
                if(d=="3"){
                    amount=2100;
                }

                String str2 = Integer.toString(amount);
                String str3="The Total Amount is ";
                JOptionPane.showMessageDialog(null,str3+str2);
                f.dispose();
                new Details();
            }
        });
        f.setSize(500,800);
        f.setLayout(null);
        f.setVisible(true);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

class Details extends Railways{
    JFrame f=new JFrame("PASSENGER DETAILS");
    public Details()
    {   f.getContentPane().setBackground(Color.PINK);
        JLabel label;
        JLabel PD=new JLabel("PASSENGER DETAILS");
        JLabel NAM =new JLabel("Name :");
        JTextField NAM_FILL=new JTextField("");
        JLabel AGE=new JLabel("Age : ");
        JTextField AGE_FILL=new JTextField();
        JLabel GEN=new JLabel("Gender :");
        Choice GEN_FILL=new Choice();
        GEN_FILL.add("Male");
        GEN_FILL.add("Female");
        JLabel PASS=new JLabel("Confirm password : ");
        JTextField  PASS_FILL= new JPasswordField();
        JLabel MOB=new JLabel("Mobile number   :");
        JTextField  MOB_FILL= new JTextField();
        JLabel PAY=new JLabel("Payment Mode:");
        Choice PAYM=new Choice();
        PAYM.add("Default");
        PAYM.add("UPI");
        PAYM.add("PAYTM");
        PAYM.add("GOOGLE PAY");
        PAYM.add("CREDIT CARD");
        PAYM.add("DEBIT CARD");
        JButton b=new JButton("Submit");
        PD.setFont(new Font("Times New Roman",Font.PLAIN,20));
        PD.setBounds(150,70,250,30);
        f.add(PD);
        NAM.setBounds(50,150,95,30);
        f.add(NAM);
        NAM_FILL.setBounds(175,157,100,20);
        f.add(NAM_FILL);
        AGE.setBounds(50,200,80,30);
        f.add(AGE);
        AGE_FILL.setBounds(175,207,30,20);
        f.add(AGE_FILL);
        GEN.setBounds(50,250,95,30);
        f.add(GEN);
        GEN_FILL.setBounds(150,250,95,30);
        f.add(GEN_FILL);
        PASS.setBounds(50,300,150,30);
        f.add(PASS);
        PASS_FILL.setBounds(175,310,95,20);
        f.add(PASS_FILL);
        MOB.setBounds(50,350,135,30);
        f.add(MOB);
        MOB_FILL.setBounds(175,360,95,20);
        f.add(MOB_FILL);
        PAY.setBounds(50,400,135,30);
        f.add(PAY);
        PAYM.setBounds(185,410,150,20);
        f.add(PAYM);
        b.setBounds(200,520,95,20);
        f.add(b);
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                {
                    JOptionPane.showMessageDialog(f,"   Your Transaction is Successful\nYour Ticket Will Be Printed Automatically\n                  Thank You!  ");
                }
            }
        });
        JButton back=new JButton("HOME");
        back.setBounds(200,580,100,20);
        f.add(back);
        back.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                f.dispose();
                try{
                    FileWriter fstream = new FileWriter(System.currentTimeMillis() + "fout.txt");
                    BufferedWriter out = new BufferedWriter(fstream);
                    out.write("Name = "+NAM_FILL.getText());
                    out.write("\n");
                    out.write("Age = "+AGE_FILL.getText());
                    out.write("\n");
                    out.write("Gender ="+GEN_FILL.getItem(GEN_FILL.getSelectedIndex()));
                    out.write("\n");
                    out.write("Mobile no : "+MOB_FILL.getText());
                    out.write("\n");
                    out.write("Mode of payment ="+PAYM.getItem(PAYM.getSelectedIndex()));
                    out.write("\n");
                    out.close();
                }
                catch (Exception e1){
                    System.err.println("Error: " + e1.getMessage());
                }new TT();
            }
        });

        f.setSize(500,800);
        f.setLayout(null);
        f.setVisible(true);
        f.setResizable(false);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

